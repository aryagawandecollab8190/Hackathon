# AI service: how to train, run and connect it

## 1. Train (Member 3, Google Colab / Kaggle, GPU)

1. Put data under `agrolens/data/` (Drive folder on Colab):
   - `plantvillage/` : PlantVillage folders (names are matched automatically)
   - `field_photos/<label>/` : real phone photos used for training (optional but strongly recommended)
   - `field_test/<label>/` : real photos **never** used for training, for the honest accuracy number
   - `non_leaf/` : photos of hands, soil, pots, etc. (optional; used to tune the threshold)
2. Run `ai-service/training/train.ipynb`, then `evaluate.ipynb`.
3. Copy `agrolens_model.keras`, `class_names.json`, `model_meta.json` from `artifacts/` into `ai-service/model/`.
4. Put the TensorFlow version printed by the notebook into `ai-service/requirements.txt`.
5. Copy the accuracy numbers from `metrics.json` into the README.

Supported v1 classes (9): tomato (early blight, late blight, leaf mold, healthy), potato (early blight,
late blight, healthy), bell pepper (bacterial spot, healthy).

## 2. Run the AI service

```bash
cd ai-service
cp .env.example .env            # set AI_SERVICE_KEY
pip install -r requirements.txt
pytest -q                       # uses a fake model; no weights needed
uvicorn app:app --port 8000
curl -H "X-API-Key: $AI_SERVICE_KEY" -F image=@leaf.jpg http://localhost:8000/predict
```

The service refuses to start if: `AI_SERVICE_KEY` is empty, the model output size differs from
`class_names.json`, or (when the seed file is reachable) a label has no entry in `diseases.json`.

## 3. Contract

`POST /predict` (multipart field `image`, header `X-API-Key`)

```json
{ "label": "tomato_early_blight", "confidence": 0.942,
  "top_predictions": [ {"label": "tomato_early_blight", "score": 0.942}, ... ] }
```
Response header `X-Model-Version`. Errors: 401 bad key, 400 not a readable JPG/PNG/WebP, 413 too large, 500 model error.
`GET /health` returns `{ "status": "ok", "modelLoaded": true }`.

## 4. Connect the backend (Member 2)

Files provided: `backend/src/services/ai.service.js`, `backend/src/utils/ApiError.js`,
`backend/src/seed/{seed.js,diseases.json,medicines.json}`.

`backend/.env`:
```
AI_SERVICE_URL=http://localhost:8000
AI_SERVICE_KEY=<same value as ai-service/.env>
AI_TIMEOUT_MS=30000
CONFIDENCE_THRESHOLD=0.70      # use the value in model_meta.json after evaluate.ipynb
AI_MOCK=true                   # frontend work without the model; remove when the real service is up
```

In `analyze.controller.js` (after the Cloudinary upload):

```js
import { predict, decideStatus } from "../services/ai.service.js";

const prediction = await predict(req.file.buffer, req.file.mimetype, req.file.originalname);
const disease = await Disease.findOne({ key: prediction.label }).populate("medicineIds");
const status = decideStatus(prediction, disease);

// low_confidence: no disease details, no medicines (safety rule)
// healthy: no medicines
// disease_detected: lang = req.body.lang in ["en","hi","mr"] else "en"; fall back to en when a translation is missing
```

Then save the `Analysis` document (`diseaseKey`, `diseaseId` null for low confidence, `confidence`,
`topPredictions`, `status`, `language`) and return the response from API_CONTRACT.md. Always attach the
disclaimer "Consult a local agriculture officer before use." next to medicines.

Load the seed once: `node src/seed/seed.js`.

## 5. Things to know

- **Content is draft.** `diseases.json` / `medicines.json` carry `"reviewStatus": "needs_expert_review"`.
  Doses and Hindi/Marathi wording must be checked by an agriculture expert and native speakers before real use.
- **Low confidence is a safety feature, not a bug.** The model only knows 9 classes; a leaf of another crop
  or disease will still get *some* prediction. The threshold and the low-confidence screen are what protect users.
- **Photo tips for the UI:** centre the leaf, fill most of the frame, good light. The service centre-crops
  to a square exactly as training did.
- **Free hosts:** TensorFlow needs ~1 GB+ RAM. If the free tier runs out of memory, export to TFLite/ONNX
  (then change the loader in `app.py`, since the loader must match the model file).
