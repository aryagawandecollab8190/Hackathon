import ApiError from "../utils/ApiError.js";

/**
 * Calls the Python AI service (POST /predict) and returns
 *   { label, confidence, topPredictions: [{ label, score }], modelVersion }
 *
 * Env: AI_SERVICE_URL, AI_SERVICE_KEY, AI_TIMEOUT_MS (default 30000),
 *      AI_MOCK=true to skip the real service during frontend development.
 * Needs Node 18+ (built-in fetch, FormData, Blob).
 */

const MOCK_RESULTS = [
  { label: "tomato_early_blight", confidence: 0.942 },
  { label: "tomato_healthy", confidence: 0.981 },
  { label: "potato_late_blight", confidence: 0.887 },
  { label: "pepper_bacterial_spot", confidence: 0.412 }, // below threshold -> low_confidence
];

function mockPredict(buffer) {
  const pick = MOCK_RESULTS[buffer.length % MOCK_RESULTS.length];
  return {
    label: pick.label,
    confidence: pick.confidence,
    topPredictions: [
      { label: pick.label, score: pick.confidence },
      { label: "tomato_late_blight", score: +((1 - pick.confidence) * 0.7).toFixed(4) },
      { label: "potato_early_blight", score: +((1 - pick.confidence) * 0.3).toFixed(4) },
    ],
    modelVersion: "mock",
  };
}

export async function predict(buffer, mimeType = "image/jpeg", filename = "leaf.jpg") {
  if (process.env.AI_MOCK === "true") return mockPredict(buffer);

  const baseUrl = process.env.AI_SERVICE_URL;
  const apiKey = process.env.AI_SERVICE_KEY;
  if (!baseUrl || !apiKey) {
    throw new ApiError(502, "AI_UNAVAILABLE", "The analysis service is not configured.");
  }
  const timeoutMs = Number(process.env.AI_TIMEOUT_MS || 30000);

  const form = new FormData();
  form.append("image", new Blob([buffer], { type: mimeType }), filename);

  let res;
  try {
    res = await fetch(`${baseUrl.replace(/\/$/, "")}/predict`, {
      method: "POST",
      headers: { "X-API-Key": apiKey },
      body: form,
      signal: AbortSignal.timeout(timeoutMs),
    });
  } catch (err) {
    if (err.name === "TimeoutError" || err.name === "AbortError") {
      throw new ApiError(504, "AI_TIMEOUT", "The analysis took too long. Please try again.");
    }
    throw new ApiError(502, "AI_UNAVAILABLE", "The analysis service is unavailable. Please try again.");
  }

  if (res.status === 400) {
    throw new ApiError(400, "INVALID_IMAGE", "The image could not be read. Please upload a clear leaf photo.");
  }
  if (res.status === 413) {
    throw new ApiError(413, "FILE_TOO_LARGE", "The image is too large.");
  }
  if (!res.ok) {
    // 401 here means AI_SERVICE_KEY differs between backend and AI service; 5xx is a model error.
    console.error(`AI service returned HTTP ${res.status}`);
    throw new ApiError(502, "AI_UNAVAILABLE", "The analysis service is unavailable. Please try again.");
  }

  const data = await res.json();
  if (typeof data.label !== "string" || typeof data.confidence !== "number") {
    throw new ApiError(502, "AI_UNAVAILABLE", "The analysis service returned an unexpected response.");
  }
  return {
    label: data.label,
    confidence: data.confidence,
    topPredictions: (data.top_predictions || []).slice(0, 3),
    modelVersion: res.headers.get("x-model-version") || "unknown",
  };
}

/** Decide the analysis status from a prediction and the disease record (if any). */
export function decideStatus(prediction, disease, threshold = Number(process.env.CONFIDENCE_THRESHOLD || 0.7)) {
  if (prediction.confidence < threshold) return "low_confidence";
  if (!disease) return "low_confidence"; // label without data: never guess
  return disease.isHealthy ? "healthy" : "disease_detected";
}
