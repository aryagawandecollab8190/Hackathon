/**
 * Loads diseases and medicines into MongoDB. Safe to run repeatedly (upserts).
 *   node src/seed/seed.js
 *
 * Also checks that every label the AI model can output has a disease entry,
 * and stops with an error if one is missing.
 */
import "dotenv/config";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import mongoose from "mongoose";
import Disease from "../models/Disease.js";
import Medicine from "../models/Medicine.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const readJson = async (p) => JSON.parse(await fs.readFile(p, "utf-8"));

async function main() {
  const medicines = await readJson(path.join(here, "medicines.json"));
  const diseases = await readJson(path.join(here, "diseases.json"));

  // Label check against the AI service (skipped when the repo layout is different, e.g. on a host).
  const classFile = path.join(here, "../../../ai-service/model/class_names.json");
  try {
    const classes = await readJson(classFile);
    const keys = new Set(diseases.map((d) => d.key));
    const missing = classes.filter((c) => !keys.has(c));
    if (missing.length) throw new Error(`Labels missing from diseases.json: ${missing.join(", ")}`);
    console.log(`Label check OK (${classes.length} classes).`);
  } catch (err) {
    if (err.code !== "ENOENT") throw err;
    console.warn("class_names.json not found; skipping label check.");
  }

  await mongoose.connect(process.env.MONGODB_URI);

  const idByName = new Map();
  for (const m of medicines) {
    const doc = await Medicine.findOneAndUpdate({ name: m.name }, m, { upsert: true, new: true, setDefaultsOnInsert: true });
    idByName.set(m.name, doc._id);
  }

  for (const { medicineNames = [], ...d } of diseases) {
    const medicineIds = medicineNames.map((n) => {
      if (!idByName.has(n)) throw new Error(`Unknown medicine "${n}" in disease ${d.key}`);
      return idByName.get(n);
    });
    await Disease.findOneAndUpdate({ key: d.key }, { ...d, medicineIds }, { upsert: true, new: true, setDefaultsOnInsert: true });
  }

  console.log(`Seeded ${medicines.length} medicines and ${diseases.length} diseases.`);
  await mongoose.disconnect();
}

main().catch(async (err) => {
  console.error(err);
  await mongoose.disconnect().catch(() => {});
  process.exit(1);
});
