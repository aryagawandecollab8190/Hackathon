/**
 * Error with an HTTP status and a machine-readable code.
 * error.middleware.js turns it into: { "error": { "code": "...", "message": "..." } }
 */
export default class ApiError extends Error {
  constructor(status, code, message) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
  }
}
