"""Image preprocessing for the AgroLens AI service.

This module MUST stay in sync with the training notebook (training/train.ipynb):

    1. decode image, convert to RGB (EXIF rotation applied)
    2. centre-crop to a square
    3. resize to IMG_SIZE x IMG_SIZE (bilinear, antialiased)
    4. keep raw pixel values 0..255 as float32

The 0..255 -> [-1, 1] scaling that MobileNetV2 expects happens INSIDE the saved
model (a Rescaling layer), so the serving side cannot get it wrong.
"""
import io

import numpy as np
from PIL import Image, ImageOps

IMG_SIZE = 224
ALLOWED_TYPES = {"jpeg", "png", "webp"}

# Guard against decompression bombs (a tiny file that expands to a huge image).
Image.MAX_IMAGE_PIXELS = 40_000_000


class ImageDecodeError(ValueError):
    """Raised when the bytes cannot be read as an image."""


def detect_image_type(data: bytes):
    """Return 'jpeg', 'png' or 'webp' from the file signature, else None.

    The file signature is checked, not the extension or the client's
    Content-Type header, because both of those can be faked.
    """
    if data[:3] == b"\xff\xd8\xff":
        return "jpeg"
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "png"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "webp"
    return None


def load_image_array(data: bytes, size: int = IMG_SIZE) -> np.ndarray:
    """Turn raw image bytes into a float32 array of shape (1, size, size, 3)."""
    try:
        with Image.open(io.BytesIO(data)) as im:
            im = ImageOps.exif_transpose(im)  # phone photos often carry rotation
            im = im.convert("RGB")
            w, h = im.size
            side = min(w, h)
            left = (w - side) // 2
            top = (h - side) // 2
            im = im.crop((left, top, left + side, top + side))
            im = im.resize((size, size), Image.BILINEAR)
            arr = np.asarray(im, dtype=np.float32)
    except Exception as exc:  # corrupt file, bomb, truncated data, ...
        raise ImageDecodeError(str(exc)) from exc
    return arr[np.newaxis, ...]
