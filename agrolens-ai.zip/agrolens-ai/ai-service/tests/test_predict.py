"""Tests for the AI service. Run from ai-service/:  pytest -q

A fake model is used, so no TensorFlow or trained weights are needed. These tests
check the HTTP contract, security checks, preprocessing, and label/seed consistency.
"""
import io
import json
import os
import sys
from pathlib import Path

import numpy as np
import pytest
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
KEY = "test-key"
os.environ["AI_SERVICE_KEY"] = KEY

import app as app_module  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from utils.preprocess import IMG_SIZE, detect_image_type, load_image_array  # noqa: E402

CLASS_NAMES = json.loads((ROOT / "model" / "class_names.json").read_text(encoding="utf-8"))


class FakeModel:
    def __init__(self, probs):
        self.probs = np.asarray([probs], dtype="float32")

    def __call__(self, x, training=False):
        assert x.shape == (1, IMG_SIZE, IMG_SIZE, 3)
        assert x.dtype == np.float32
        return self.probs


def make_image(fmt="PNG", size=(120, 80), mode="RGB"):
    buf = io.BytesIO()
    Image.new(mode, size, (30, 160, 60) if mode == "RGB" else 128).save(buf, fmt)
    return buf.getvalue()


@pytest.fixture
def client(monkeypatch):
    probs = np.full(len(CLASS_NAMES), 0.02)
    probs[2], probs[0], probs[1] = 0.80, 0.08, 0.04
    probs = probs / probs.sum()
    monkeypatch.setitem(app_module.state, "model", FakeModel(probs))
    monkeypatch.setitem(app_module.state, "class_names", CLASS_NAMES)
    monkeypatch.setitem(app_module.state, "meta", {"model_version": "test-v1"})
    monkeypatch.setenv("AI_SERVICE_KEY", KEY)
    return TestClient(app_module.app)  # no `with`: the lifespan (real model load) is skipped


def post(client, data, key=KEY, name="leaf.png", ctype="image/png"):
    headers = {"X-API-Key": key} if key else {}
    return client.post("/predict", files={"image": (name, data, ctype)}, headers=headers)


def test_health(client):
    assert client.get("/health").json() == {"status": "ok", "modelLoaded": True}


def test_predict_success_shape_and_header(client):
    r = post(client, make_image())
    assert r.status_code == 200
    body = r.json()
    assert set(body) == {"label", "confidence", "top_predictions"}
    assert body["label"] == CLASS_NAMES[2]
    assert len(body["top_predictions"]) == 3
    scores = [p["score"] for p in body["top_predictions"]]
    assert scores == sorted(scores, reverse=True)
    assert body["confidence"] == scores[0]
    assert r.headers["X-Model-Version"] == "test-v1"


@pytest.mark.parametrize("key", [None, "wrong"])
def test_rejects_bad_key(client, key):
    assert post(client, make_image(), key=key).status_code == 401


def test_rejects_non_image_even_with_image_extension(client):
    assert post(client, b"this is plain text", name="x.png").status_code == 400


def test_rejects_corrupt_image_with_valid_signature(client):
    corrupt = b"\x89PNG\r\n\x1a\n" + b"garbage" * 20
    assert post(client, corrupt).status_code == 400


def test_rejects_oversize(client, monkeypatch):
    monkeypatch.setenv("MAX_IMAGE_MB", "0.001")
    noise = np.random.default_rng(0).integers(0, 255, (64, 64, 3), dtype=np.uint8)
    buf = io.BytesIO()
    Image.fromarray(noise).save(buf, "PNG")
    assert post(client, buf.getvalue()).status_code == 413


@pytest.mark.parametrize("fmt,ctype", [("JPEG", "image/jpeg"), ("PNG", "image/png"), ("WEBP", "image/webp")])
def test_accepts_allowed_formats(client, fmt, ctype):
    assert post(client, make_image(fmt), ctype=ctype).status_code == 200


def test_preprocess_output_contract():
    for mode in ("RGB", "L", "RGBA"):
        arr = load_image_array(make_image("PNG", (300, 200), mode))
        assert arr.shape == (1, IMG_SIZE, IMG_SIZE, 3)
        assert arr.dtype == np.float32
        assert 0.0 <= arr.min() and arr.max() <= 255.0


def test_detect_image_type():
    assert detect_image_type(make_image("JPEG")) == "jpeg"
    assert detect_image_type(make_image("PNG")) == "png"
    assert detect_image_type(make_image("WEBP")) == "webp"
    assert detect_image_type(b"%PDF-1.4") is None


def test_class_names_unique():
    assert len(CLASS_NAMES) == len(set(CLASS_NAMES))


def test_every_label_has_seed_data():
    seed = ROOT.parent / "backend" / "src" / "seed" / "diseases.json"
    if not seed.exists():
        pytest.skip("seed file not present")
    keys = {d["key"] for d in json.loads(seed.read_text(encoding="utf-8"))}
    assert set(CLASS_NAMES) <= keys, f"missing: {set(CLASS_NAMES) - keys}"
