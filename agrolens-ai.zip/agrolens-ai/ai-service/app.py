"""AgroLens AI service: serves the MobileNetV2 leaf-disease classifier.

Run locally (from the ai-service folder):
    uvicorn app:app --reload --port 8000

Endpoints
    POST /predict   multipart field "image", header X-API-Key
    GET  /health
"""
import hmac
import json
import logging
import os
import threading
from contextlib import asynccontextmanager
from pathlib import Path

import numpy as np
from dotenv import load_dotenv
from fastapi import FastAPI, File, Header, HTTPException, UploadFile
from fastapi.responses import JSONResponse

from utils.preprocess import (
    IMG_SIZE,
    ImageDecodeError,
    detect_image_type,
    load_image_array,
)

load_dotenv()
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
log = logging.getLogger("agrolens.ai")

BASE_DIR = Path(__file__).resolve().parent
TOP_K = 3

# Filled once at start-up, never per request.
state = {"model": None, "class_names": [], "meta": {}}
_predict_lock = threading.Lock()


def _path(env_name: str, default: str) -> Path:
    p = Path(os.getenv(env_name, default))
    return p if p.is_absolute() else BASE_DIR / p


def _load_model(model_path: Path):
    """Load the saved model. The extension decides the loader, so it must match
    the single format the team chose when exporting."""
    ext = model_path.suffix.lower()
    if ext not in (".keras", ".h5"):
        raise RuntimeError(
            f"Unsupported model format '{ext}'. This service loads .keras or .h5 files."
        )
    if not model_path.exists():
        raise RuntimeError(f"Model file not found: {model_path}")
    import tensorflow as tf  # imported here so the module imports fast in tests

    return tf.keras.models.load_model(model_path, compile=False)


def _check_seed_coverage(class_names):
    """Every label the model can output must have disease data in the seed file."""
    seed_path = _path("SEED_DISEASES_PATH", "../backend/src/seed/diseases.json")
    if not seed_path.exists():
        log.warning("Seed file %s not found; skipping label coverage check.", seed_path)
        return
    keys = {d["key"] for d in json.loads(seed_path.read_text(encoding="utf-8"))}
    missing = sorted(set(class_names) - keys)
    if missing:
        raise RuntimeError(f"Labels without disease data in the seed file: {missing}")


def load_resources():
    if not os.getenv("AI_SERVICE_KEY"):
        raise RuntimeError("AI_SERVICE_KEY is not set; refusing to start unprotected.")

    class_names = json.loads(
        _path("CLASS_NAMES_PATH", "model/class_names.json").read_text(encoding="utf-8")
    )
    if not isinstance(class_names, list) or len(set(class_names)) != len(class_names):
        raise RuntimeError("class_names.json must be a list of unique labels.")

    model = _load_model(_path("MODEL_PATH", "model/agrolens_model.keras"))
    outputs = int(model.output_shape[-1])
    if outputs != len(class_names):
        raise RuntimeError(
            f"Model has {outputs} outputs but class_names.json has {len(class_names)} labels."
        )
    model(np.zeros((1, IMG_SIZE, IMG_SIZE, 3), dtype="float32"), training=False)  # warm-up

    meta_path = _path("MODEL_META_PATH", "model/model_meta.json")
    meta = json.loads(meta_path.read_text(encoding="utf-8")) if meta_path.exists() else {}
    meta.setdefault("model_version", "unknown")

    _check_seed_coverage(class_names)
    state.update(model=model, class_names=class_names, meta=meta)
    log.info("Model %s loaded with %d classes.", meta["model_version"], len(class_names))


@asynccontextmanager
async def lifespan(_app: FastAPI):
    load_resources()
    yield


app = FastAPI(title="AgroLens AI Service", lifespan=lifespan)


def _check_key(provided):
    expected = os.getenv("AI_SERVICE_KEY", "")
    if not expected or not provided or not hmac.compare_digest(provided, expected):
        raise HTTPException(status_code=401, detail="Invalid or missing API key.")


@app.get("/health")
def health():
    return {"status": "ok", "modelLoaded": state["model"] is not None}


@app.post("/predict")
def predict(
    image: UploadFile = File(...),
    x_api_key: str | None = Header(default=None),
):
    _check_key(x_api_key)
    if state["model"] is None:
        raise HTTPException(status_code=503, detail="Model is not loaded.")

    max_bytes = int(float(os.getenv("MAX_IMAGE_MB", "5")) * 1024 * 1024)
    data = image.file.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise HTTPException(status_code=413, detail="Image is too large.")
    if not data or detect_image_type(data) is None:
        raise HTTPException(status_code=400, detail="Only JPG, PNG or WebP images are accepted.")

    try:
        batch = load_image_array(data)
    except ImageDecodeError:
        raise HTTPException(status_code=400, detail="The image could not be read.")

    try:
        with _predict_lock:
            probs = np.asarray(state["model"](batch, training=False))[0]
    except Exception:
        log.exception("Inference failed")
        raise HTTPException(status_code=500, detail="Model inference failed.")

    names = state["class_names"]
    order = np.argsort(probs)[::-1][:TOP_K]
    top = [{"label": names[i], "score": round(float(probs[i]), 4)} for i in order]
    body = {
        "label": top[0]["label"],
        "confidence": top[0]["score"],
        "top_predictions": top,
    }
    return JSONResponse(body, headers={"X-Model-Version": str(state["meta"]["model_version"])})
